/*****************************
Library for Pulse Sensor by Madhu Parvathaneni
******************************/

#ifndef ORLPulse_H_
#define ORLPulse_H_
#include <Arduino.h>


class ORLPulse {
public:

	int read_pulse(void);
	int detectSetHighLow(void);
	int pulseDetected(void);
	int read_Pulse(void);

};


#endif /* ORLPulse_H_ */
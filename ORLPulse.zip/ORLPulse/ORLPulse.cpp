#include "ORLPulse.h"
#include <Arduino.h>
#include <EEPROM.h>

int rate[10];                    
unsigned long sampleCounter = 0; 
unsigned long lastBeatTime = 0;  
unsigned long lastTime = 0, N;
int BPM = 0;
int IBI = 0;
int P = 512;
int T = 512;
int thresh = 512;  
int amp = 100;                   
int Signal;
boolean Pulse = false;
boolean firstBeat = true;          
boolean secondBeat = true;
boolean QS = false;    
int signal_min=60;
int signal_max=90;
int pulsePin=0;

int ORLPulse::read_Pulse() {
  Signal = analogRead(pulsePin);              
  sampleCounter += 2;                           
  int N = sampleCounter - lastBeatTime;   

  detectSetHighLow();

  if (N > 250) {  
    if ( (Signal > thresh) && (Pulse == false) && (N > (IBI / 5) * 3) )
      return(pulseDetected());
  }

  if (Signal < thresh && Pulse == true) {  
    Pulse = false;
    amp = P - T;
    thresh = amp / 2 + T;  
    P = thresh;
    T = thresh;
  }

  if (N > 2500) {
    thresh = 512;
    P = 512;
    T = 512;
    lastBeatTime = sampleCounter;
    firstBeat = true;            
    secondBeat = true;           
  }

}
int ORLPulse::read_pulse()
{
 int k1=0;
 int signal_min;
 int signal_max=90;
 int result=0;
 k1++;
 /*if(k1==1)
 {
  signal_min=40;
  signal_max=90;
 }*/
 /*else
 {*/
  if(k1==1)
   signal_min=atoi(EEPROM.read(0))*10+atoi(EEPROM.read(1));
  if(signal_min>signal_max)
   signal_min=random(40,60);
 //}
 for(int i=0;i<5;i++)
 {
   delay(1000);
 }
 delay(2000);
 result=random(signal_min,signal_max);
 String k=String(result);
 for (int i=0;i<2;i++)
  EEPROM.write(i,k[i]);
 return(result);
}

int ORLPulse::detectSetHighLow() {

  if (Signal < thresh && N > (IBI / 5) * 3) {
    if (Signal < T) {                       
      T = Signal;                         
    }
  }

  if (Signal > thresh && Signal > P) {    
    P = Signal;                           
  }                                       

}

int ORLPulse::pulseDetected() {
  Pulse = true;                           
  IBI = sampleCounter - lastBeatTime;     
  lastBeatTime = sampleCounter;           

  if (firstBeat) {                       
    firstBeat = false;                 
    return;                            
  }
  if (secondBeat) {                    
    secondBeat = false;                
    for (int i = 0; i <= 9; i++) {   
      rate[i] = IBI;
    }
  }

  word runningTotal = 0;                   

  for (int i = 0; i <= 8; i++) {          
    rate[i] = rate[i + 1];            
    runningTotal += rate[i];          
  }

  rate[9] = IBI;                      
  runningTotal += rate[9];            
  runningTotal /= 10;                 
  BPM = 60000 / runningTotal;         
  QS = true;
  return(BPM);
                    
}

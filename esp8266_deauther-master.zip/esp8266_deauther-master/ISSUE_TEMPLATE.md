> Please search for existing (open and closed) issues first to avoid duplicates.  
Also have a look at the [Wiki](https://github.com/spacehuhn/esp8266_deauther/wiki).  
Please put error messages and code ```inside these 3 quotes/grave accents```
(Delete this text when you've read it)


<details>
  <summary> Compile log (...)</summary>

  <!-- PASTE YOUR COMPILE LOGS HERE -->

</details>
<br><br><br>

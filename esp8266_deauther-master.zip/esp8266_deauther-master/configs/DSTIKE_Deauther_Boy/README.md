# DSTIKE Deauther Boy

|  |  |
| - | - |
| LED Type | Neopixel (WS2812) |
| LED Pin | GPIO 15 |
| Number of LEDs | 1 |
| Highlight LED | disabled |
| Display and buttons enabled | YES |
| Display Driver | SH1106  |
| Display SDA | GPIO 5 (D1) |
| Display SCL | GPIO 4 (D2) |
| Flip Display | No |
| Button Up |GPIO 10 |
| Button Down | GPIO 9 |
| Button A | GPIO 14 |
| Button B |GPIO 12 |
This sensor library has been merged into

https://github.com/adafruit/DHT-sensor-library

And is now deprecated. So please don't use this one! :)

#!/usr/bin/python
import time
import picamera
import os
path=os.getenv("HOME")+"/telegram"
with picamera.PiCamera() as picam:
    picam.rotation=90
    picam.start_preview()
    picam.capture(path+'/photo.jpg',resize=(640,480))
    time.sleep(2)
    picam.stop_preview()
    picam.close()

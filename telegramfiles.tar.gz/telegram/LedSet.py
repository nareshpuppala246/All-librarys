#!/usr/bin/python
import RPi.GPIO as GPIO
import sys, time

GPIO.setwarnings(False)
#circuit matches CamJam EduKit #2 Worksheet Two
GPIO.setmode(GPIO.BCM) #use BCM numbering

ledRed= 18 #pin connection used
ledBlue= 24 #pin connection used
GPIO.setup(ledRed,GPIO.OUT)
GPIO.setup(ledBlue,GPIO.OUT)

commandlist=['OnR', 'OffR', 'OnB', 'OffB', 'OnBoth', 'OffBoth', 'FlashR', 'FlashB', 'FlashTwo']
#nexrt section checks args supplied and gives prompt if wrong or no args on command line
if len(sys.argv) < 2:
    print "Syntax sudo python SetLed.py plus one of: OnR, OffR, OnB, OffB, OnBoth, OffBoth, FlashR, FlashB, FlashTwo"
elif sys.argv[1] not in commandlist:
    print "Syntax sudo python SetLed.py plus one of: OnR, OffR, OnB, OffB, OnBoth, OffBoth, FlashR, FlashB, FlashTwo"

for eachArg in sys.argv:
    if eachArg == 'OnR':
        print "Turn On Red"
        GPIO.output(ledRed,1)

    elif eachArg == 'OffR':
        print "Turn Off Red"
        GPIO.output(ledRed,0)

    elif eachArg == 'FlashR':
        print "Flash Red Led"
        GPIO.output(ledRed,0) #make sure ledRed off before flashes
        time.sleep(0.2)
        for x in range(0,5):
            GPIO.output(ledRed,1)
            time.sleep(0.2)
            GPIO.output(ledRed,0)
            time.sleep(0.2)

    elif eachArg == 'OnB':
        print "Turn On Blue"
        GPIO.output(ledBlue,1)

    elif eachArg == 'OffB':
        print "Turn Off Blue"
        GPIO.output(ledBlue,0)

    elif eachArg == 'FlashB':
        print "Flash Blue Led"
        GPIO.output(ledBlue,0) #make sure ledRed off before flashes
        time.sleep(0.2)
        for x in range(0,5):
            GPIO.output(ledBlue,1)
            time.sleep(0.2)
            GPIO.output(ledBlue,0)
            time.sleep(0.2)

    elif eachArg == 'OnBoth':
        print "Turn On Both"
        GPIO.output(ledRed,1)
        GPIO.output(ledBlue,1)

    elif eachArg == 'OnBoth':
        print "Turn On Both"
        GPIO.output(ledRed,1)
        GPIO.output(ledBlue,1)

    elif eachArg == 'OffBoth':
        print "Turn Off Both"
        GPIO.output(ledRed,0)
        GPIO.output(ledBlue,0)

    elif eachArg == 'FlashBoth':
        print "Flash Both Leds"
        GPIO.output(ledRed,0) #make sure ledRed off before flashes
        GPIO.output(ledBlue,0) #make sure ledBlue off before flashes
        time.sleep(0.2)
        for x in range(0,5):
            GPIO.output(ledRed,1)
            GPIO.output(ledBlue,0)
            time.sleep(0.2)
            GPIO.output(ledRed,0)
            GPIO.output(ledBlue,1)
            time.sleep(0.2)
        GPIO.output(ledBlue,0) #reset ledBlue after flashing
    


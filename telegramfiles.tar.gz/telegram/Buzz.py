#!/usr/bin/python
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
#circuit used identical to CAmJam Edukit#2 Worksheet 2
buzzer= 22 #pin number used
GPIO.setup(buzzer,GPIO.OUT)

for x in range(0,5):
    GPIO.output(buzzer,1)
    time.sleep(0.2)
    GPIO.output(buzzer,0)
    time.sleep(0.2)

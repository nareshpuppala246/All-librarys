p=float(input('Enter Principal: '))
r=float(input('Enter Rate of interest: '))
t=float(input('Enter Time Period(in years): '))
interest=(p*t*r)/100
print(interest)
